<?php
/**
 * Template Name: Invasive Aquatic Weed Control
 *
 * Renders for the Page with slug "invasive-weed-control"; awh_create_pages() creates it.
 * Content mirrors the approved static invasive-weed-control.html.
 *
 * @package aquatic-weed
 */

get_header();
?>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can you work around public beaches?",
      "acceptedAnswer": { "@type": "Answer", "text": "Yes. Treatment areas and scheduling can be coordinated around swimming areas, visitor access, events, and peak recreation periods." }
    },
    {
      "@type": "Question",
      "name": "Do you work with lake associations?",
      "acceptedAnswer": { "@type": "Answer", "text": "Yes. Projects can be scoped around shared docks, beaches, boat lanes, coves, and other association priorities." }
    },
    {
      "@type": "Question",
      "name": "Do you provide municipal lake weed management?",
      "acceptedAnswer": { "@type": "Answer", "text": "Yes. We support municipal vegetation-management programs for public lakes, ponds, parks, beaches, and boat launches." }
    },
    {
      "@type": "Question",
      "name": "Do you use aquatic herbicides?",
      "acceptedAnswer": { "@type": "Answer", "text": "No. We use mechanical equipment to cut, collect, and remove unwanted aquatic vegetation." }
    },
    {
      "@type": "Question",
      "name": "When should invasive weeds be harvested?",
      "acceptedAnswer": { "@type": "Answer", "text": "Timing depends on the species. Water chestnut, for example, should generally be removed before mature plants release seeds." }
    }
  ]
}
</script>

<main id="main">

<!-- ============ PAGE HERO ============ -->
<section class="shero on-dark">
  <figure class="shero__panel">
    <img src="<?php echo awh_img( 'crew-full-operation.webp' ); ?>" width="1280" height="960" loading="eager" decoding="async" fetchpriority="high"
      alt="The work boat, excavator and haul truck running as one operation on a shared waterfront.">
  </figure>

  <div class="shero__inner">
    <p class="phero__crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> <i>/</i> <a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Services</a> <i>/</i> <b>Invasive aquatic weed control</b></p>
    <h1 class="shero__title">Invasive Aquatic Weed <em>Control</em></h1>
    <p class="shero__lead">Control invasive vegetation affecting public beaches, community lakes,
    boat launches, and shared waterfronts. We mechanically harvest unwanted growth, collect the cut
    vegetation, and remove the biomass from the water.</p>

    <div class="shero__cta">
      <a class="btn btn--primary btn--lg" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Request a Site Assessment <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
      <a class="btn btn--ghost btn--lg" href="tel:+15184417742">Call (518) 441-7742</a>
    </div>

    <ul class="shero__specs">
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Municipal lakes and ponds</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Public beaches and boat launches</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Lake and homeowner associations</li>
    </ul>
  </div>
</section>

<!-- ============ PUBLIC & COMMUNITY WATERBODIES ============ -->
<section class="section" id="programs">
  <div class="wrap">
    <div class="approach">
      <div class="approach__aside reveal">
        <p class="eyebrow">Who we work with</p>
        <h2 class="h2">Invasive weed management for public and community waterbodies.</h2>
      </div>

      <ul class="approach__list">
        <li class="approach__item reveal">
          <span class="approach__n">01</span>
          <div>
            <h3 class="approach__h">Municipal lake weed management</h3>
            <p class="approach__p">Support ongoing vegetation management for town and village lakes,
            public ponds, parks, boat launches, and recreational waterfronts. We coordinate removal
            around public access, seasonal demand, and priority areas identified by the
            municipality.</p>
            <ul class="svc__list">
              <li>Public lakes and ponds</li>
              <li>Parks and recreation areas</li>
              <li>Boat launches and access channels</li>
              <li>Targeted seasonal harvesting</li>
            </ul>
          </div>
        </li>

        <li class="approach__item reveal">
          <span class="approach__n">02</span>
          <div>
            <h3 class="approach__h">Public beach weed removal service</h3>
            <p class="approach__p">Dense aquatic growth can affect swimming areas, shorelines, and
            how visitors experience a public beach. Our compact work boat targets vegetation in
            shallow and frequently used areas.</p>
            <ul class="svc__list">
              <li>Swimming and wading areas</li>
              <li>Beachfront shorelines</li>
              <li>Access routes and safety zones</li>
              <li>Scheduling around public use</li>
            </ul>
          </div>
        </li>

        <li class="approach__item reveal">
          <span class="approach__n">03</span>
          <div>
            <h3 class="approach__h">Lake association weed harvesting</h3>
            <p class="approach__p">Lake and homeowner associations often need to balance multiple
            properties, shared access points, and annual maintenance priorities. We work with
            association representatives to define treatment areas and create a harvesting plan for
            the waterbody.</p>
            <ul class="svc__list">
              <li>Community swim areas</li>
              <li>Shared docks and boat lanes</li>
              <li>High-priority coves and shorelines</li>
              <li>Seasonal maintenance programs</li>
            </ul>
          </div>
        </li>
      </ul>
    </div>
  </div>
</section>

<!-- ============ SPECIES ============ -->
<section class="section section--rule" id="species">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">What we control</p>
      <h2 class="h2">Invasive aquatic vegetation we control.</h2>
    </div>

    <div class="wfront wfront--4">
      <article class="wfrontCard reveal">
        <img src="<?php echo awh_img( 'weed-milfoil.jpg' ); ?>" width="1200" height="600" loading="lazy" decoding="async"
             alt="Eurasian watermilfoil in a dense underwater stand, tips breaking the surface.">
        <div class="wfrontCard__body">
          <h3 class="wfrontCard__h">Eurasian watermilfoil removal</h3>
          <p class="wfrontCard__p">Our targeted Eurasian Watermilfoil removal services address dense
          underwater growth that impedes swimming, boating, and the health of native ecosystems.
          Through careful mechanical harvesting and complete collection of cut fragments, we prevent
          further spreading across your waterbody.</p>
        </div>
      </article>

      <article class="wfrontCard reveal">
        <img src="<?php echo awh_img( 'weed-chestnut.jpg' ); ?>" width="1200" height="600" loading="lazy" decoding="async"
             alt="A water chestnut rosette floating on open water, spiked seed visible at the edge.">
        <div class="wfrontCard__body">
          <h3 class="wfrontCard__h">Water chestnut removal</h3>
          <p class="wfrontCard__p">We specialize in water chestnut removal to clear heavy floating
          mats restricting access to shorelines and open water. Our team schedules harvesting
          operations early in the season to extract vegetation before mature plants drop seeds.</p>
        </div>
      </article>

      <article class="wfrontCard reveal">
        <img src="<?php echo awh_img( 'weed-hydrilla.jpg' ); ?>" width="1200" height="600" loading="lazy" decoding="async"
             alt="Hydrilla growing in thick submerged mats below the waterline.">
        <div class="wfrontCard__body">
          <h3 class="wfrontCard__h">Lake hydrilla eradication service</h3>
          <p class="wfrontCard__p">Our professional lake hydrilla eradication service targets
          aggressive, rapid submerged growth. We combine mechanical removal with structured, ongoing
          monitoring to manage recurrent growth and restore clarity to affected water bodies.</p>
        </div>
      </article>

      <article class="wfrontCard reveal">
        <img src="<?php echo awh_img( 'weed-lily.jpg' ); ?>" width="1200" height="600" loading="lazy" decoding="async"
             alt="Lily pads covering the surface of shallow water.">
        <div class="wfrontCard__body">
          <h3 class="wfrontCard__h">Additional vegetation management services</h3>
          <p class="wfrontCard__p">We also offer customized harvesting solutions for lily pads,
          cattails, algae mats, and other nuisance aquatic weeds.</p>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ============ WHY MECHANICAL ============ -->
<section class="section section--band on-dark" id="why">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">The approach</p>
      <h2 class="h2">Why use mechanical harvesting?</h2>
    </div>

    <div class="kit">
      <figure class="kit__media reveal">
        <img src="<?php echo awh_img( 'conveyor-load.jpg' ); ?>" width="2048" height="1536" loading="lazy" decoding="async"
             alt="A full load of cut vegetation riding the boat's conveyor on its way off the water.">
      </figure>

      <ul class="kit__list">
        <li class="kit__row reveal">
          <span class="kit__tag">01</span>
          <div>
            <h3 class="kit__h">Immediate physical control</h3>
            <p class="kit__p">Harvesting removes existing vegetation from the selected treatment
            area rather than waiting for it to break down.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">02</span>
          <div>
            <h3 class="kit__h">Biomass removal</h3>
            <p class="kit__p">Collected plant material is removed from the water rather than being
            left to decompose.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">03</span>
          <div>
            <h3 class="kit__h">Targeted treatment areas</h3>
            <p class="kit__p">Prioritize beaches, docks, navigation channels, launches, and other
            high-use areas, rather than treating the entire waterbody.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">04</span>
          <div>
            <h3 class="kit__h">Flexible scheduling</h3>
            <p class="kit__p">Coordinate work around public events, peak recreation periods,
            association requirements, and seasonal plant growth.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">05</span>
          <div>
            <h3 class="kit__h">No herbicide application</h3>
            <p class="kit__p">Mechanical harvesting controls vegetation without using aquatic
            herbicides. Any access requirements are reviewed based on the project and local
            regulations.</p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</section>

<!-- ============ PROJECT SCOPE ============ -->
<section class="section section--wavetop" id="scope">
  <svg class="wavetop" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
    <path class="w1" d="M0 60c180 40 320-30 520-10s300 60 480 30 260-40 440-20v70H0z"/>
    <path class="w2" d="M0 80c200 30 340-20 540 5s320 50 500 20 220-30 400-15v55H0z"/>
  </svg>
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">Before work begins</p>
      <h2 class="h2">A clear scope for every project.</h2>
      <p class="lead">Municipal and association projects often involve public-use requirements and
      strict budget constraints. Before work begins, we establish a clear project scope that
      defines:</p>
    </div>

    <ul class="offers">
      <li class="spec reveal"><b>Priority treatment areas</b></li>
      <li class="spec reveal"><b>Target vegetation</b></li>
      <li class="spec reveal"><b>Estimated project schedule</b></li>
      <li class="spec reveal"><b>Equipment access</b></li>
      <li class="spec reveal"><b>Biomass handling and disposal</b></li>
      <li class="spec reveal"><b>Required permits or approvals</b></li>
      <li class="spec reveal"><b>Documentation requirements</b></li>
      <li class="spec reveal"><b>Point of contact for project decisions</b></li>
    </ul>
  </div>
</section>

<!-- ============ FAQ ============ -->
<section class="section" id="faq">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">Questions</p>
      <h2 class="h2">Invasive aquatic weed control questions.</h2>
    </div>

    <div class="faq">
      <details class="faq__item reveal">
        <summary class="faq__q">Can you work around public beaches?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Yes. Treatment areas and scheduling can be coordinated around swimming
        areas, visitor access, events, and peak recreation periods.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Do you work with lake associations?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Yes. Projects can be scoped around shared docks, beaches, boat lanes,
        coves, and other association priorities.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Do you provide municipal lake weed management?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Yes. We support municipal vegetation-management programs for public lakes,
        ponds, parks, beaches, and boat launches.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Do you use aquatic herbicides?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">No. We use mechanical equipment to cut, collect, and remove unwanted
        aquatic vegetation.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">When should invasive weeds be harvested?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Timing depends on the species. Water chestnut, for example, should
        generally be removed before mature plants release seeds.</p>
      </details>
    </div>
  </div>
</section>

<!-- ============ CTA ============ -->
<section class="section section--cta on-dark">
  <div class="wrap cta">
    <div class="cta__copy reveal">
      <p class="eyebrow">Site assessment</p>
      <h2 class="cta__h">Build a clear plan for your waterbody.</h2>
      <p class="cta__p">Tell us about the invasive vegetation, affected areas, public-use
      requirements, and seasonal priorities. We will review the project and recommend an appropriate
      mechanical harvesting approach.</p>
    </div>
    <div class="cta__side reveal">
      <a class="cta__call" href="tel:+15184417742">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h3l2 5-2.5 1.5a11 11 0 005 5L15 12l5 2v3a2 2 0 01-2.2 2C11 18.4 5.6 13 5 6.2A2 2 0 016 3z"/></svg>
        <span><b>+1 (518) 441-7742</b><em>jim@wedowaterweeds.com</em></span>
      </a>
      <a class="btn btn--primary btn--lg btn--block" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Request a Site Assessment <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

</main>

<?php
get_footer();
