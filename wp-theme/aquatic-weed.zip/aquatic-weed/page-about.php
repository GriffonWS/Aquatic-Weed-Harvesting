<?php
/**
 * Template Name: About
 *
 * Renders for the Page with slug "about"; awh_create_pages() creates it.
 * Content mirrors the approved static about.html.
 *
 * @package aquatic-weed
 */

get_header();
?>

<main id="main" class="page-about">

<!-- ============ PAGE HERO ============ -->
<section class="phero phero--photo on-dark">
  <div class="phero__photo">
    <img src="<?php echo awh_img( 'crew-full-operation.webp' ); ?>" width="1280" height="960" fetchpriority="high" decoding="async"
      alt="The work boat, excavator and haul truck working together to clear a weed-choked waterfront.">
  </div>
  <div class="wrap phero__inner">
    <p class="phero__crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> <i>/</i> <b>About Aquatic Weed Harvesting LLC</b></p>
    <h1 class="phero__title">Aquatic Weed Removal Built for <em>Shallow Water</em></h1>
    <p class="phero__lead">Aquatic Weed Harvesting LLC provides mechanical removal of aquatic vegetation, muck, shoreline material, and debris from lakes and ponds across the Northeast and beyond.</p>
    <p class="phero__lead">Based in the Hudson Valley, we help homeowners, lake associations, commercial properties, and municipalities restore access to overgrown water without applying aquatic herbicides.</p>
    <div class="phero__cta">
      <a class="btn btn--primary btn--lg" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Request a Free Estimate <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
      <a class="btn btn--ghost btn--lg" href="tel:+15184417742">Call +1 (518) 441-7742</a>
    </div>

    <ul class="shero__specs about__proof">
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Founded in 2018</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>More than 334 completed projects</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Fully insured</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Rapid response time</li>
    </ul>
  </div>
</section>

<!-- ============ OUR FOCUS ============ -->
<section class="section section--wavetop" id="focus">
  <svg class="wavetop" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
    <path class="w1" d="M0 60c180 40 320-30 520-10s300 60 480 30 260-40 440-20v70H0z"/>
    <path class="w2" d="M0 80c200 30 340-20 540 5s320 50 500 20 220-30 400-15v55H0z"/>
  </svg>
  <div class="wrap">
    <div class="section__head section__head--split section__head--top reveal">
      <div>
        <p class="eyebrow">Lake and Pond Cleanup Made for Difficult Water</p>
        <h2 class="h2">Got Lake Weeds?</h2>
      </div>
      <div class="subhead__body">
        <p class="lead">Many aquatic weed problems develop in shallow coves, around docks, along shorelines, and in smaller waterways where full-size harvesters may not have enough room or depth to operate.</p>
        <p class="lead">Our agile workboats have an 8-inch shallow draft, allowing us to reach vegetation in shallow and confined areas. Their design also provides greater flexibility when working around waterfront structures and in changing surface conditions.</p>
        <p class="lead">We assess each waterbody individually and select the equipment based on the vegetation, debris, sediment, depth, and property access.</p>
      </div>
    </div>
  </div>
</section>

<!-- ============ EXPERIENCE ============ -->
<section class="section section--rule" id="experience">
  <div class="wrap">
    <div class="section__head section__head--split section__head--top reveal">
      <div>
        <p class="eyebrow">Experience</p>
        <h2 class="h2">Focused on Mechanical Aquatic Removal Since 2018</h2>
      </div>
      <div class="subhead__body">
        <p class="lead">Since 2018, we have completed more than 334 projects for private waterfront owners, lake associations, commercial properties, and municipalities.</p>
        <p class="lead">Our work includes:</p>
        <ul class="shero__specs about__work">
          <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Aquatic weed harvesting</li>
          <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Lake and pond weed removal</li>
          <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Shoreline vegetation removal</li>
          <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Muck and organic sediment removal</li>
          <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Leaf and floating debris cleanup</li>
          <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Invasive aquatic weed control</li>
          <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Branch and downed-log removal</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- ============ EQUIPMENT CAPABILITIES ============ -->
<section class="section section--boat on-dark" id="equipment">
  <div class="wrap">
  <div class="boat">
    <div class="boat__copy reveal">
      <p class="eyebrow">Equipment Capabilities</p>
      <h2 class="h2">Designed to Reach the Weeds</h2>
      <p class="lead">Many aquatic weed problems develop in shallow areas around docks, shorelines, coves, and pond edges. Our workboats have an 8-inch shallow draft, allowing them to reach areas where larger harvesting equipment may not have sufficient depth or operating space.</p>
    </div>
    <div class="boat__figure reveal">
      <figure class="shot shot--feature">
        <img src="<?php echo awh_img( 'mechanical.webp' ); ?>" width="1600" height="1200" loading="lazy" decoding="async"
             alt="The shallow-draft work boat cutting and collecting aquatic vegetation.">
      </figure>
    </div>
  </div>
    <ul class="boat__specs boat__specs--wide boat__specs--four reveal">
      <li class="spec"><b>8-Inch Shallow Draft</b><span>Provides access to shallow water where excessive growth often collects.</span></li>
      <li class="spec"><b>5-to-6-Foot Cutting Depth</b><span>Allows submerged vegetation to be cut well below the water&rsquo;s surface.</span></li>
      <li class="spec"><b>Five Quick-Change Attachments</b><span>The cutter, vegetation bucket, skimmer bucket, root rake, and hydraulic pole saw allow the equipment to adapt to different vegetation and debris.</span></li>
      <li class="spec"><b>Two-Boat Capability</b><span>Two workboats can be deployed when appropriate for the project&rsquo;s size and conditions.</span></li>
    </ul>
  </div>
</section>

<!-- ============ PERMITS ============ -->
<section class="section section--wavetop" id="permits">
  <svg class="wavetop" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
    <path class="w1" d="M0 60c180 40 320-30 520-10s300 60 480 30 260-40 440-20v70H0z"/>
    <path class="w2" d="M0 80c200 30 340-20 540 5s320 50 500 20 220-30 400-15v55H0z"/>
  </svg>
  <div class="wrap">
    <div class="section__head section__head--split section__head--top reveal">
      <div>
        <p class="eyebrow">Permits</p>
        <h2 class="h2">Guidance Through the Permitting Process</h2>
      </div>
      <div class="subhead__body">
        <p class="lead">Permit requirements vary by state, waterbody, plant species, and project type.</p>
        <p class="lead">Aquatic Weed Harvesting LLC does not issue permits, but we can help customers identify the appropriate agency or contact. We are also available to answer project-related questions during the permitting process when needed.</p>
      </div>
    </div>
    <p class="serve__note reveal">Customers remain responsible for obtaining any required approvals before work begins.</p>
  </div>
</section>

<!-- ============ TESTIMONIALS ============ -->
<!-- Hidden until real client quotes are supplied: the brief only has
     "[CLIENT TESTIMONIAL]" placeholders, which must not go live. Fill in the
     quotes and remove the hidden attribute to show the section. -->
<section class="section section--rule" id="testimonials" hidden>
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">Testimonials</p>
      <h2 class="h2">What Our Customers Say</h2>
    </div>
    <div class="about__quotes">
      <figure class="about__quote reveal">
        <blockquote>&ldquo;[CLIENT TESTIMONIAL]&rdquo;</blockquote>
        <figcaption><b>[CUSTOMER NAME OR INITIALS]</b><span>[PROPERTY TYPE OR LOCATION]</span></figcaption>
      </figure>
      <figure class="about__quote reveal">
        <blockquote>&ldquo;[CLIENT TESTIMONIAL]&rdquo;</blockquote>
        <figcaption><b>[CUSTOMER NAME OR INITIALS]</b><span>[PROPERTY TYPE OR LOCATION]</span></figcaption>
      </figure>
    </div>
  </div>
</section>

<!-- ============ CTA ============ -->
<section class="section section--cta on-dark">
  <div class="wrap cta">
    <div class="cta__copy reveal">
      <p class="eyebrow">Free Initial Review</p>
      <h2 class="cta__h">Put Our Experience to Work on Your Water</h2>
      <p class="cta__p">Tell us what is affecting your lake, pond, or shoreline and which areas need attention. We will review the conditions, recommend an appropriate mechanical removal plan, and provide a no-obligation estimate.</p>
    </div>
    <div class="cta__side reveal">
      <a class="cta__call" href="tel:+15184417742">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h3l2 5-2.5 1.5a11 11 0 005 5L15 12l5 2v3a2 2 0 01-2.2 2C11 18.4 5.6 13 5 6.2A2 2 0 016 3z"/></svg>
        <span><b>Call +1 (518) 441-7742</b></span>
      </a>
      <a class="btn btn--primary btn--lg btn--block" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Request a Free Estimate <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

</main>

<?php
get_footer();
