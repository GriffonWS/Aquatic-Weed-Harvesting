<?php
/**
 * Template Name: Aquatic Weed Harvesting
 *
 * Renders for the Page with slug "aquatic-weed-harvesting"; awh_create_pages() creates it.
 * Content mirrors the approved static aquatic-weed-harvesting.html.
 *
 * @package aquatic-weed
 */

get_header();
?>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "How do I know which service I need?",
      "acceptedAnswer": { "@type": "Answer", "text": "Share details about the affected area and include photos if available. We will identify the likely vegetation and recommend the appropriate removal approach." }
    },
    {
      "@type": "Question",
      "name": "Is an estimate free?",
      "acceptedAnswer": { "@type": "Answer", "text": "Yes. Initial estimates are provided without charge or obligation." }
    },
    {
      "@type": "Question",
      "name": "Will the weeds grow back?",
      "acceptedAnswer": { "@type": "Answer", "text": "Mechanical aquatic weed harvesting is a maintenance service rather than permanent eradication. Regrowth varies by species, waterbody, and seasonal conditions." }
    },
    {
      "@type": "Question",
      "name": "Do you remove the cut vegetation?",
      "acceptedAnswer": { "@type": "Answer", "text": "Yes. Collected vegetation and debris are hauled away from the property." }
    },
    {
      "@type": "Question",
      "name": "When should I schedule service?",
      "acceptedAnswer": { "@type": "Answer", "text": "Timing depends on the species and project. Early scheduling is especially important for invasive plants that spread through seeds or fragments carried by boat traffic, wildlife, and currents." }
    }
  ]
}
</script>

<main id="main">

<!-- ============ PAGE HERO ============ -->
<!-- The home page's hero (photo behind the copy, ripple canvas, waves), with
     .hero--page tuning the headline down for a longer, keyword-carrying title.
     The breadcrumb sits in the eyebrow pill where the home page has its tagline. -->
<section class="hero hero--page on-dark">
  <div class="hero__photo">
    <img src="<?php echo awh_img( 'boat-in-weeds.jpg' ); ?>" width="1400" height="876" fetchpriority="high" decoding="async"
      alt="The yellow work boat cutting a path through a pond covered bank to bank in weed.">
  </div>
  <canvas class="hero__canvas" id="ripple" aria-hidden="true"></canvas>
  <div class="hero__glow" aria-hidden="true"></div>

  <div class="hero__inner">
    <p class="hero__eyebrow phero__crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> <i>/</i> <a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Services</a> <i>/</i> <b>Aquatic weed harvesting</b></p>
    <h1 class="hero__title">
      <span class="line"><span>Mechanical Aquatic Weed <em>Harvesting</em></span></span>
      <span class="line"><span>for Lakes, Ponds, and Shorelines</span></span>
    </h1>
    <p class="hero__lead">Based in the Hudson Valley, Aquatic Weed Harvesting LLC uses a sustainable mechanical process to cut, collect, and remove unwanted aquatic vegetation and biomass without herbicides across New York, New Jersey, and Pennsylvania.</p>

    <div class="hero__cta">
      <a class="btn btn--primary btn--lg" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Request a Free Estimate <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
      <a class="btn btn--ghost btn--lg" href="tel:+15184417742">Call +1 (518) 441-7742</a>
    </div>

    <ul class="shero__specs">
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Vegetation collected during removal</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Cuts up to 5 feet below the surface</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Off-site hauling and disposal included</li>
    </ul>
  </div>

  <svg class="hero__waves" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
    <path class="w1" d="M0 60c180 40 320-30 520-10s300 60 480 30 260-40 440-20v70H0z" />
    <path class="w2" d="M0 80c200 30 340-20 540 5s320 50 500 20 220-30 400-15v55H0z" />
  </svg>

  <a class="hero__scroll" href="#system" aria-label="Scroll down"><span></span></a>
</section>

<!-- ============ ONE ADAPTABLE SYSTEM ============ -->
<section class="section" id="system">
  <div class="wrap">
    <div class="approach">
      <div class="approach__aside reveal">
        <p class="eyebrow">Built for Difficult Water</p>
        <h2 class="h2">One Adaptable System for Challenging Waterfronts</h2>
        <p class="lead">Every body of water presents different vegetation, depths, obstacles, and access conditions. Our workboat uses five quick-change attachments, allowing us to match the removal method to the conditions instead of forcing every project into the same process.</p>
      </div>

      <ul class="approach__list">
        <li class="approach__item reveal">
          <span class="approach__n">01</span>
          <div>
            <h3 class="approach__h">Shallow-Water Access</h3>
            <p class="approach__p">Work in areas where full-size harvesting equipment may not have
            sufficient depth or room.</p>
          </div>
        </li>
        <li class="approach__item reveal">
          <span class="approach__n">02</span>
          <div>
            <h3 class="approach__h">Targeted Removal</h3>
            <p class="approach__p">Focus on the specific areas affecting swimming, boating,
            waterfront access, or property use.</p>
          </div>
        </li>
        <li class="approach__item reveal">
          <span class="approach__n">03</span>
          <div>
            <h3 class="approach__h">Complete Collection</h3>
            <p class="approach__p">Capture removed vegetation during the project and transport it
            away from the property.</p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</section>

<!-- ============ PROCESS ============ -->
<!-- Dark band: sets the three steps apart as a sequence, and gives the
     .wavetop on the equipment section below something to wave out of. -->
<section class="section section--band on-dark" id="process">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">The Process</p>
      <h2 class="h2">From Assessment to Removal</h2>
    </div>

    <ol class="flow">
      <li class="flow__step reveal">
        <figure class="flow__media">
          <img src="<?php echo awh_img( 'lake-ramp-weed.webp' ); ?>" width="1024" height="498" loading="lazy" decoding="async"
               alt="A weed-choked lake seen from the launch ramp, before any work begins.">
        </figure>
        <div class="flow__bar"><span class="flow__n">1</span><span class="flow__rule"></span></div>
        <h3 class="flow__h">Show Us the Water</h3>
        <p class="flow__p">Share basic information about the affected area and, if available, include photos. We identify the vegetation and determine whether mechanical removal is suitable.</p>
      </li>
      <li class="flow__step reveal">
        <figure class="flow__media">
          <img src="<?php echo awh_img( 'weedoo-work-boat-poster.jpg' ); ?>" width="1400" height="786" loading="lazy" decoding="async"
               alt="The shallow-draft work boat staged and ready with its interchangeable attachment.">
        </figure>
        <div class="flow__bar"><span class="flow__n">2</span><span class="flow__rule"></span></div>
        <h3 class="flow__h">Select the Right Equipment</h3>
        <p class="flow__p">We match the workboat attachment to the vegetation, debris, water depth, and access conditions.</p>
      </li>
      <li class="flow__step reveal">
        <figure class="flow__media">
          <img src="<?php echo awh_img( 'loading-dump-truck.webp' ); ?>" width="1280" height="960" loading="lazy" decoding="async"
               alt="An excavator loading harvested weed into a dump truck to be hauled off site.">
        </figure>
        <div class="flow__bar"><span class="flow__n">3</span><span class="flow__rule"></span></div>
        <h3 class="flow__h">Cut, Collect and Haul Away</h3>
        <p class="flow__p">The material is mechanically removed, collected during the project, and
        transported away from the property.</p>
      </li>
    </ol>

    <p class="flow__cta reveal">
      <a class="btn btn--primary btn--lg" href="<?php echo esc_url( home_url( '/how-it-works/' ) ); ?>#process">See How the Process Works <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
    </p>
  </div>
</section>

<!-- ============ ONE BOAT, FOUR TOOLS ============ -->
<section class="section section--wavetop" id="equipment">
  <svg class="wavetop" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
    <path class="w1" d="M0 60c180 40 320-30 520-10s300 60 480 30 260-40 440-20v70H0z"/>
    <path class="w2" d="M0 80c200 30 340-20 540 5s320 50 500 20 220-30 400-15v55H0z"/>
  </svg>
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">The Equipment</p>
      <h2 class="h2">One Workboat<br>Five Quick-Change Attachments</h2>
      <p class="lead">The same shallow-draft workboat handles every service. Five quick-change attachments allow it to cut submerged vegetation, scoop heavier growth, skim fine material and algae, clear rooted shoreline vegetation, and remove branches or logs.
      <a class="offer__link" href="<?php echo esc_url( home_url( '/how-it-works/' ) ); ?>#equipment">Explore the equipment <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a></p>
    </div>

    <div class="kit">
      <figure class="kit__media reveal">
        <img src="<?php echo awh_img( 'machine.png' ); ?>" width="768" height="432" loading="lazy" decoding="async"
             alt="A quick-change cutter attachment mounted on the work boat, operator at the controls.">
      </figure>

      <ul class="kit__list">
        <li class="kit__row reveal">
          <span class="kit__tag">01</span>
          <div>
            <h3 class="kit__h">Cutter</h3>
            <p class="kit__p">Cuts aquatic vegetation up to 5 feet below the surface while collecting the cut material.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">02</span>
          <div>
            <h3 class="kit__h">Vegetation Bucket / Front-End Loader</h3>
            <p class="kit__p">Scoops vegetation from water up to 3 feet deep.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">03</span>
          <div>
            <h3 class="kit__h">Skimmer Bucket</h3>
            <p class="kit__p">Collects algae mats, duckweed, leaves, and other floating material.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">04</span>
          <div>
            <h3 class="kit__h">Root Rake</h3>
            <p class="kit__p">Cuts branches, small trees, and downed wood from the water side.</p>
          </div>
        </li>
        <li class="kit__row reveal">
          <span class="kit__tag">05</span>
          <div>
            <h3 class="kit__h">Hydraulic Pole Saw</h3>
            <p class="kit__p">Cuts tree branches, small trees, and downed logs in the water.</p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</section>

<!-- ============ EVERY WATERFRONT ============ -->
<!-- No .wavetop: the section above it is light too, so the wave (which is
     filled with the page colour) would have nothing to show against. -->
<section class="section section--serve" id="waterfronts">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">Every Waterfront</p>
      <h2 class="h2">Chemical-Free Removal for Every Type of Waterfront</h2>
    </div>

    <div class="wfront">
      <article class="wfrontCard reveal">
        <img src="<?php echo awh_img( 'pond-estate-weed.jpg' ); ?>" width="1024" height="768" loading="lazy" decoding="async"
             alt="A private estate pond with dense surface vegetation, house on the rise behind it.">
        <span class="wfrontCard__ico" aria-hidden="true">
          <svg viewBox="0 0 24 24"><path d="M3 11l9-7 9 7"/><path d="M5.5 9.6V20h13V9.6"/><path d="M9.5 20v-5h5v5"/></svg>
        </span>
        <div class="wfrontCard__body">
          <h3 class="wfrontCard__h">Residential</h3>
          <p class="wfrontCard__p">Private lakefronts, backyard ponds, swim areas, docks, and boat
          access points.</p>
        </div>
      </article>

      <article class="wfrontCard reveal">
        <img src="<?php echo awh_img( 'crew-full-operation.webp' ); ?>" width="1280" height="960" loading="lazy" decoding="async"
             alt="A full crew running a commercial job — work boat, excavator and haul truck on the bank.">
        <span class="wfrontCard__ico" aria-hidden="true">
          <svg viewBox="0 0 24 24"><path d="M3.5 9.5h17V20h-17z"/><path d="M2.5 9.5L5 4h14l2.5 5.5z"/><path d="M9.5 20v-6.5h5V20"/></svg>
        </span>
        <div class="wfrontCard__body">
          <h3 class="wfrontCard__h">Commercial</h3>
          <p class="wfrontCard__p">Campgrounds, marinas, golf courses, resorts, HOAs, and lake
          associations.</p>
        </div>
      </article>

      <article class="wfrontCard reveal">
        <img src="<?php echo awh_img( 'lakeside-crew.webp' ); ?>" width="1024" height="540" loading="lazy" decoding="async"
             alt="Harvested vegetation staged on a public lakeside access point for removal.">
        <span class="wfrontCard__ico" aria-hidden="true">
          <svg viewBox="0 0 24 24"><path d="M3 21h18"/><path d="M4 21V9h16v12"/><path d="M2.5 9L12 3.5 21.5 9"/><path d="M8 21v-7h3v7M14 14h2.5v7"/></svg>
        </span>
        <div class="wfrontCard__body">
          <h3 class="wfrontCard__h">Municipal</h3>
          <p class="wfrontCard__p">Public beaches, boat launches, parks, conservation districts,
          and community waterbodies.</p>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ============ FAQ ============ -->
<section class="section" id="faq">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">Questions</p>
      <h2 class="h2">Aquatic Weed Removal Questions</h2>
    </div>

    <div class="faq">
      <details class="faq__item reveal">
        <summary class="faq__q">How do I know which service I need?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Share details about the affected area and include photos if available. We will identify the likely vegetation and recommend the appropriate removal approach.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Is an estimate free?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Yes. Initial estimates are provided without charge or obligation.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Will the weeds grow back?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Mechanical aquatic weed harvesting is a maintenance service rather than
        permanent eradication. Regrowth varies by species, waterbody, and seasonal conditions.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Do you remove the cut vegetation?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Yes. Collected vegetation and debris are hauled away from the property.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">When should I schedule service?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Timing depends on the species and project. Early scheduling is especially important for invasive plants that spread through seeds or fragments carried by boat traffic, wildlife, and currents.</p>
      </details>
    </div>
  </div>
</section>

<!-- ============ CTA ============ -->
<section class="section section--cta on-dark">
  <div class="wrap cta">
    <div class="cta__copy reveal">
      <p class="eyebrow">Free Estimate</p>
      <h2 class="cta__h">Get a Clear Plan for Your Waterfront</h2>
      <p class="cta__p">Tell us what is growing, where the problem is located, and how it is affecting your property. We will recommend the appropriate mechanical removal approach and provide a no-obligation estimate.</p>
    </div>
    <div class="cta__side reveal">
      <a class="cta__call" href="tel:+15184417742">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h3l2 5-2.5 1.5a11 11 0 005 5L15 12l5 2v3a2 2 0 01-2.2 2C11 18.4 5.6 13 5 6.2A2 2 0 016 3z"/></svg>
        <span><b>+1 (518) 441-7742</b></span>
      </a>
      <a class="btn btn--primary btn--lg btn--block" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Get a Free Estimate <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

</main>

<?php
get_footer();
