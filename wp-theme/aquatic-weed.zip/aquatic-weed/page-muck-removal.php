<?php
/**
 * Template Name: Muck Removal
 *
 * Renders for the Page with slug "muck-removal"; awh_create_pages() creates it.
 * Content mirrors the approved static muck-removal.html.
 *
 * @package aquatic-weed
 */

get_header();
?>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is lake or pond muck?",
      "acceptedAnswer": { "@type": "Answer", "text": "Muck is soft organic sediment formed when vegetation, algae, leaves, and other natural materials settle and decompose on the bottom." }
    },
    {
      "@type": "Question",
      "name": "Do you physically remove the muck?",
      "acceptedAnswer": { "@type": "Answer", "text": "Yes. Existing organic sediment is mechanically lifted and removed from the selected treatment area." }
    },
    {
      "@type": "Question",
      "name": "Is muck removal the same as weed removal?",
      "acceptedAnswer": { "@type": "Answer", "text": "No. Weed removal targets living aquatic vegetation. Muck removal addresses organic sediment that has already accumulated on the bottom. The services can be combined when both problems are present." }
    },
    {
      "@type": "Question",
      "name": "Do you use chemical muck treatments?",
      "acceptedAnswer": { "@type": "Answer", "text": "No. We physically remove organic sediment using mechanical equipment." }
    }
  ]
}
</script>

<main id="main">

<!-- ============ PAGE HERO ============ -->
<section class="hero hero--page on-dark">
  <div class="hero__photo">
    <img src="<?php echo awh_img( 'muck-reduction-2.jpg' ); ?>" width="1600" height="1200" decoding="async" fetchpriority="high"
      alt="The work boat's rake lifting a heavy load of dark muck and lily roots out of a pond.">
  </div>
  <canvas class="hero__canvas" id="ripple" aria-hidden="true"></canvas>
  <div class="hero__glow" aria-hidden="true"></div>

  <div class="hero__inner">
    <p class="hero__eyebrow phero__crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> <i>/</i> <a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Services</a> <i>/</i> <b>Muck removal</b></p>
    <h1 class="hero__title">
      <span class="line"><span>Lake Muck Removal and</span></span>
      <span class="line"><span>Pond Muck <em>Reduction</em></span></span>
    </h1>
    <p class="hero__lead">Remove accumulated organic sediment from problem areas in lakes and
    ponds. Our mechanical muck removal service targets decomposed vegetation, leaves, algae, and
    other organic material that has settled on the bottom.</p>

    <div class="hero__cta">
      <a class="btn btn--primary btn--lg" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Request a Free Estimate <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
      <a class="btn btn--ghost btn--lg" href="tel:+15184417742">Call +1 (518) 441-7742</a>
    </div>

    <ul class="shero__specs">
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Physical removal of existing muck</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Targeted lake and pond treatment</li>
      <li class="shero__spec"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>Sustainable removal without chemical muck treatments</li>
    </ul>
  </div>

  <svg class="hero__waves" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
    <path class="w1" d="M0 60c180 40 320-30 520-10s300 60 480 30 260-40 440-20v70H0z" />
    <path class="w2" d="M0 80c200 30 340-20 540 5s320 50 500 20 220-30 400-15v55H0z" />
  </svg>

  <a class="hero__scroll" href="#sediment" aria-label="Scroll down"><span></span></a>
</section>

<!-- ============ BEYOND SURFACE WEEDS ============ -->
<section class="section" id="sediment">
  <div class="wrap">
    <div class="approach">
      <div class="approach__aside reveal">
        <p class="eyebrow">What Muck Is</p>
        <h2 class="h2">Organic Sediment Removal for Lakes and Ponds</h2>
        <p class="lead">Lake and pond muck forms as aquatic vegetation, algae, leaves, and other biomass settle and decompose on the bottom. Over time, this soft organic sediment can reduce water depth, create unstable bottom conditions, and restrict access around docks, shorelines, and swimming areas.</p>
        <p class="lead">This service goes beyond surface weed removal. We physically extract accumulated organic sediment from targeted areas and can pair the work with aquatic vegetation and debris removal to address both existing buildup and the material contributing to future accumulation.</p>
      </div>

      <ul class="approach__list">
        <li class="approach__item reveal">
          <span class="approach__n">01</span>
          <div>
            <h3 class="approach__h">Restore Shallow Areas</h3>
            <p class="approach__p">Removing accumulated sediment can recover usable depth around
            docks, shorelines, swimming areas, and other priority sections.</p>
          </div>
        </li>
        <li class="approach__item reveal">
          <span class="approach__n">02</span>
          <div>
            <h3 class="approach__h">Improve Bottom Conditions</h3>
            <p class="approach__p">Targeted organic sediment removal can reduce soft, unstable muck
            in frequently used areas.</p>
          </div>
        </li>
        <li class="approach__item reveal">
          <span class="approach__n">03</span>
          <div>
            <h3 class="approach__h">Remove Decaying Material</h3>
            <p class="approach__p">Extract decomposed vegetation, algae, leaves, and other organic
            matter that has collected on the bottom.</p>
          </div>
        </li>
        <li class="approach__item reveal">
          <span class="approach__n">04</span>
          <div>
            <h3 class="approach__h">Address Future Buildup</h3>
            <p class="approach__p">Combine muck reduction with aquatic vegetation and debris removal
            to reduce additional organic material entering the pond or lake bottom.</p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</section>

<!-- ============ TARGETED AREAS ============ -->
<section class="section section--rule" id="areas">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">Where We Work</p>
      <h2 class="h2">Targeted Lake and Pond Muck Reduction Service</h2>
      <p class="lead">Muck does not accumulate evenly across an entire waterbody. Wind, currents,
      surrounding trees, aquatic vegetation, and shoreline conditions often concentrate organic
      material into coves, dock areas, shallow corners, and protected shorelines in both lakes and
      ponds.</p>
      <p class="lead">We focus our muck removal and reduction services on specific areas where
      bottom sediment creates the greatest disruption, including:</p>
    </div>

    <ul class="offers offers--3">
      <li class="spec reveal"><b>Docks and boat access points</b></li>
      <li class="spec reveal"><b>Swimming and wading areas</b></li>
      <li class="spec reveal"><b>Shallow coves</b></li>
      <li class="spec reveal"><b>Waterfront shorelines</b></li>
      <li class="spec reveal"><b>Areas affected by decomposing vegetation</b></li>
      <li class="spec reveal"><b>Locations where leaves and organic debris collect</b></li>
    </ul>

    <p class="serve__note reveal">Our service is suitable for private, farm, community, commercial,
    and recreational ponds, as well as targeted lake shorelines.</p>
  </div>
</section>

<!-- ============ PROCESS ============ -->
<!-- Dark band: sets the four steps apart as a sequence, and gives the
     .wavetop on the section below something to wave out of. -->
<section class="section section--band on-dark" id="process">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">The Process</p>
      <h2 class="h2">How Mechanical Muck Removal Works</h2>
    </div>

    <ol class="flow flow--4">
      <li class="flow__step reveal">
        <figure class="flow__media">
          <img src="<?php echo awh_img( 'pond-estate-weed.jpg' ); ?>" width="1024" height="768" loading="lazy" decoding="async"
               alt="A private pond under a full mat of surface growth, with the bank behind it.">
        </figure>
        <div class="flow__bar"><span class="flow__n">1</span><span class="flow__rule"></span></div>
        <h3 class="flow__h">Assess the Buildup</h3>
        <p class="flow__p">We review the affected area, sediment conditions, water depth, access,
        and the lake or pond's use.</p>
      </li>

      <li class="flow__step reveal">
        <figure class="flow__media">
          <img src="<?php echo awh_img( 'lake-ramp-weed.webp' ); ?>" width="1024" height="498" loading="lazy" decoding="async"
               alt="A shallow weedy corner of a lake seen from the launch ramp.">
        </figure>
        <div class="flow__bar"><span class="flow__n">2</span><span class="flow__rule"></span></div>
        <h3 class="flow__h">Define the Removal Area</h3>
        <p class="flow__p">The project focuses on specific locations such as docks, swimming areas,
        shorelines, coves, and shallow pond sections.</p>
      </li>

      <li class="flow__step reveal">
        <figure class="flow__media">
          <video class="is-pillarboxed" src="<?php echo awh_img( 'muck-reduction.mp4' ); ?>" poster="<?php echo awh_img( 'muck-reduction-poster.jpg' ); ?>"
                 width="320" height="240" autoplay muted loop playsinline preload="metadata"
                 aria-label="Organic muck being lifted from the bottom and out of the water."></video>
        </figure>
        <div class="flow__bar"><span class="flow__n">3</span><span class="flow__rule"></span></div>
        <h3 class="flow__h">Remove the Sediment</h3>
        <p class="flow__p">Existing organic sediment is mechanically lifted and removed from the
        bottom.</p>
      </li>

      <li class="flow__step reveal">
        <figure class="flow__media">
          <img src="<?php echo awh_img( 'loading-dump-truck.webp' ); ?>" width="1280" height="960" loading="lazy" decoding="async"
               alt="An excavator loading collected material into a dump truck to be hauled off site.">
        </figure>
        <div class="flow__bar"><span class="flow__n">4</span><span class="flow__rule"></span></div>
        <h3 class="flow__h">Manage the Removed Material</h3>
        <p class="flow__p">The collected material is transferred out of the water and managed in
        accordance with the property conditions and the agreed project scope.</p>
      </li>
    </ol>

    <p class="flow__cta reveal">
      <a class="btn btn--primary btn--lg" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Ask About Your Waterbody <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
    </p>
  </div>
</section>

<!-- ============ PHYSICAL REMOVAL ============ -->
<section class="section section--wavetop" id="physical">
  <svg class="wavetop" viewBox="0 0 1440 130" preserveAspectRatio="none" aria-hidden="true">
    <path class="w1" d="M0 60c180 40 320-30 520-10s300 60 480 30 260-40 440-20v70H0z"/>
    <path class="w2" d="M0 80c200 30 340-20 540 5s320 50 500 20 220-30 400-15v55H0z"/>
  </svg>
  <div class="wrap">
    <div class="section__head section__head--split reveal">
      <div>
        <p class="eyebrow">Mechanical, Not Chemical</p>
        <h2 class="h2">Sustainable Physical Removal Without Chemical Treatments</h2>
      </div>
      <div class="subhead__body">
        <p class="lead">Chemical and biological muck treatments are intended to accelerate
        decomposition, but they do not physically extract the accumulated material from the
        waterbody.</p>
        <p class="lead">Mechanical lake muck removal lifts the sediment from the bottom and
        removes it from the treated area.</p>
      </div>
    </div>

    <div class="kit">
      <figure class="kit__media reveal">
        <img src="<?php echo awh_img( 'muck-reduction-1.jpg' ); ?>" width="1200" height="1600" loading="lazy" decoding="async"
             alt="Muck and roots hanging from the raised rake as water drains back into the pond.">
      </figure>

      <div>
        <ul class="kit__list">
          <li class="kit__row reveal">
            <span class="kit__tag">01</span>
            <h3 class="kit__h">Existing Sediment is Physically Removed</h3>
          </li>
          <li class="kit__row reveal">
            <span class="kit__tag">02</span>
            <h3 class="kit__h">Priority Areas Can Be Targeted</h3>
          </li>
          <li class="kit__row reveal">
            <span class="kit__tag">03</span>
            <h3 class="kit__h">No Chemical Muck Treatment Applied</h3>
          </li>
          <li class="kit__row reveal">
            <span class="kit__tag">04</span>
            <h3 class="kit__h">Suitable for Lakes and Ponds</h3>
          </li>
          <li class="kit__row reveal">
            <span class="kit__tag">05</span>
            <h3 class="kit__h">Can Be Combined with Vegetation Removal</h3>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- ============ FAQ ============ -->
<section class="section" id="faq">
  <div class="wrap">
    <div class="section__head reveal">
      <p class="eyebrow">Questions</p>
      <h2 class="h2">Muck Removal Questions</h2>
    </div>

    <div class="faq">
      <details class="faq__item reveal">
        <summary class="faq__q">What is lake or pond muck?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Muck is soft organic sediment formed when vegetation, algae, leaves, and
        other natural materials settle and decompose on the bottom.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Do you physically remove the muck?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">Yes. Existing organic sediment is mechanically lifted and removed from the
        selected treatment area.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Is muck removal the same as weed removal?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">No. Weed removal targets living aquatic vegetation. Muck removal addresses
        organic sediment that has already accumulated on the bottom. The services can be combined
        when both problems are present.</p>
      </details>

      <details class="faq__item reveal">
        <summary class="faq__q">Do you use chemical muck treatments?
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        </summary>
        <p class="faq__a">No. We physically remove organic sediment using mechanical equipment.</p>
      </details>
    </div>
  </div>
</section>

<!-- ============ CTA ============ -->
<section class="section section--cta on-dark">
  <div class="wrap cta">
    <div class="cta__copy reveal">
      <p class="eyebrow">Free Initial Assessment</p>
      <h2 class="cta__h">Find Out What It Takes to Remove the Muck</h2>
      <p class="cta__p">Send us photos and basic information about your lake or pond. We will review
      the affected area, discuss the removal options, and provide a no-obligation estimate.</p>
    </div>
    <div class="cta__side reveal">
      <a class="cta__call" href="tel:+15184417742">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h3l2 5-2.5 1.5a11 11 0 005 5L15 12l5 2v3a2 2 0 01-2.2 2C11 18.4 5.6 13 5 6.2A2 2 0 016 3z"/></svg>
        <span><b>+1 (518) 441-7742</b><em>jim@wedowaterweeds.com</em></span>
      </a>
      <a class="btn btn--primary btn--lg btn--block" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>#quote">Request a Free Estimate <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

</main>

<?php
get_footer();
